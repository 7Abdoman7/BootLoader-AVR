## Flashing Utility Readme

### Overview
This project is a flashing utility designed for AVR microcontrollers, providing a graphical user interface (GUI) for users to upload firmware (in .hex format) onto their AVR devices via a serial connection.

### Features
- **GUI Interface**: Utilizes PyQt5 to create a user-friendly GUI for selecting hex files, specifying COM ports, and initiating flashing.
- **Serial Communication**: Establishes communication with AVR microcontrollers over a serial port (COM port).
- **Flashing Manager**: Manages the process of uploading firmware to the AVR device.
- **Error Handling**: Provides error messages and notifications through PyQt message boxes for user interaction.

### Components
1. **Main Program (`main.c`)**
   - Contains the main firmware logic for the AVR microcontroller.
   - Handles initialization, UART communication, and flashing initiation based on external triggers.
  
2. **GUI (`GUI.py` and `UI_Form.py`)**
   - Implements the graphical user interface using PyQt5.
   - Allows users to select hex files, specify COM ports, and start the flashing process.

3. **Flashing Manager (`FlashingMngr.py` and `Flashing_Mngr.h` in AVR)**
   - Manages the flashing process, including serial communication with the AVR device.
   - Coordinates the upload of firmware onto the AVR microcontroller.

4. **Serial Communication Manager (`ComMngr.py`)**
   - Handles communication over the serial port (COM port) with the AVR microcontroller.
   - Detects available COM ports and establishes a connection for flashing.

### How to Use
1. **Setup**
   - Ensure you have Python and PyQt5 installed on your system.
   - Install the required libraries.

2. **Running the Application**
   - Execute `python main.py` to launch the flashing utility GUI.
   - Use the GUI to:
     - Click **Load Hex File** to select the firmware (.hex) file to upload.
     - Click **Detect** to automatically detect and select the appropriate COM port.
     - Click **Start Flashing** to initiate the firmware upload process to the AVR microcontroller.

3. **Flashing Process**
   - Connect the AVR microcontroller via a compatible serial (COM) port (USB ttl).
   - Ensure the AVR device is in the appropriate state (e.g., waiting for flashing instructions) by putting the pin B0 to GND.
   - Follow the GUI instructions to load the firmware and start the flashing process.

### Requirements
- **Hardware**: AVR microcontroller compatible with UART flashing.
- **Software**: Python (for running the GUI), AVR-GCC (for compiling AVR firmware), and necessary AVR development tools.

### Notes
- This utility is designed for educational and hobbyist use.
- Ensure proper connections and configurations to prevent any damage to the AVR microcontroller or connected hardware.

## License
This project is created and maintained by Abdelrahman Elsayed and is licensed under the MIT License.

### Support or Contact
- Watch the attached video.
