/*
 * Flashing_Mngr.h
 *
 *  Created on: Jun 8, 2020
 *      Author: elProf
 */

#ifndef FLASHING_MNGR_H_
#define FLASHING_MNGR_H_

void flashingMngr_vidMainTask() ;
void flashingMngr_vidHandleReqFromApp(void);

#endif /* FLASHING_MNGR_H_ */
