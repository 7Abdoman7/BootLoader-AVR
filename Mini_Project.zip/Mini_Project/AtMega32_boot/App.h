/*
 * App.h
 *
 *  Created on: Jun 15, 2020
 *      Author: elProf
 */

#ifndef APP_H_
#define APP_H_

#define APP_SECTION	0
#define BLD_SECTION	1

extern void APP_vidMoveIVT(u8 u8Section) ;

#endif /* APP_H_ */
