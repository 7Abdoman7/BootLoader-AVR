
#include "STD_TYPES.h"
#include "macros.h"
#include <avr/io.h>
#include "UART.h"

#define IDLE 		0
#define RUNNING		1

#define UART_RX_COMPLETE	vect(13)


u8 u8len;
u8 au8RxBuffer[255];

void UART_Init(void) {
  // Set BaudRate -> 9600/11.502900MhZ
  UBRRL = 70;
  UBRRH = 0;
  // Set Frame Format -> 8 data, 1 stop, No Parity
  UCSRC = 0x86;
  // Enable RX and TX and Rx interrupt
  UCSRB = 0x18;

#if USE_INTERRUPT == 1
  UCSRB |= 0x80;
  /*Enable Global interrupt*/
  asm("sei");
#endif

}

void UART_SendChar(u8 data) {
  // Wait until transmission Register Empty
  while((UCSRA&0x20) == 0x00);
  UDR = data;

}

u8 UART_GetChar(void) {
  u8 Result;
  // Wait until Reception Complete
  while((UCSRA&0x80) == 0x00);
  Result = UDR;
  
  /* Clear Flag */
  set_bit(UCSRA,7);
  return Result;
}

#if USE_INTERRUPT == 1
ISR(UART_RX_COMPLETE) {
	static u8 RxState = IDLE;
	static u8 bufferIdx = 0;

	if (RxState == IDLE) {
		u8len = UDR;
		RxState = RUNNING;
	}
	else {
		au8RxBuffer[bufferIdx] = UDR;
		bufferIdx ++ ;
		if(bufferIdx == u8len) {
			/*all data is received */
			bufferIdx = 0;
			RxState = IDLE;

			/*call application callback*/
			flashing_vidRxNotification(au8RxBuffer , u8len);
		}
	}
}

#else

void UART_vidRxHandler(void) {
	static u8 RxState = IDLE;
	static u8 bufferIdx = 0;

	/*Check if a byte received*/
	if ((get_bit(UCSRA, 7)) == 1) {
		if (RxState == IDLE) {
			u8len = UDR;
			RxState = RUNNING;
		}
		else {
			au8RxBuffer[bufferIdx] = UDR;
			bufferIdx ++ ;
			if(bufferIdx == u8len) {
				/*all data is received */
				bufferIdx = 0;
				RxState = IDLE;
				/*call application callback*/
				flashing_vidRxNotification(au8RxBuffer , u8len);
			}
		}
		clr_bit(UCSRA, 7);
	}
}
#endif

