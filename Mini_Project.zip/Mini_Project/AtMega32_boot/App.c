
#include "STD_Types.h"
#include "macros.h"
#include "App.h"
#include "UART.h"
#include "Flashing_Mngr.h"
#include <avr/io.h>

int main(void) {
	clr_bit(DDRB,0);
	set_bit(PORTB,0);
	
	if (get_bit(PINB,0) == 0) {
		/*for debugging*/
		set_bit(DDRA,7);
		set_bit(PORTA,7);

		UART_Init();
		clr_bit(DDRD,0);
		set_bit(DDRD,1);
		
#if USE_INTERRUPT == 1
		/*Move Vector Table to boot loader section*/
		APP_vidMoveIVT(BLD_SECTION);
#endif

		flashingMngr_vidHandleReqFromApp() ;

		while (1) {
		#if USE_INTERRUPT == 0
			UART_vidRxHandler();
		#endif
			flashingMngr_vidMainTask();
		}
	}
	else if (get_bit(PINB,0) == 1) {
		/*Valid app, jump directly*/
		asm("jmp 0");
	}

	return 1 ;
}

extern void APP_vidMoveIVT(u8 u8Section) {
	/*Move IVt to Application [starting from 0]*/
	if(u8Section == APP_SECTION) {
		/* Enable change of interrupt vectors */
		GICR = (1<<IVCE);
		/* Move interrupts to Application section */
		clr_bit(GICR,IVSEL);
	}

	/*Move IVt to Bootloader [starting after end of app section]*/
	else {
		/* Enable change of interrupt vectors */
		GICR = (1<<IVCE);
		/* Move interrupts to boot Flash section */
		GICR = (1<<IVSEL);
	}
}


